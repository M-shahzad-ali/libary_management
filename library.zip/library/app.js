class book{
    constructor(name,bookname,rollno){
        this.username=name;
        this.userbook=bookname;
        this.userrollno=rollno;

    }
}

class store{
    
    static getdata(){
        var bookaray;
        var bookdata = localStorage.getItem("book");
        if(bookdata==null){

            bookaray=[];
        }
        else{
             bookaray =JSON.parse(bookdata);
                
        }
        return bookaray;
    }
    static adddata(book){
        var data = store.getdata();
        data.push(book)
        localStorage.setItem("book",JSON.stringify(data))
    }
    static  deldata(btn){ 
        let data =store.getdata();
        data.forEach((e,index)=>{
            console.log(index)
            if(e.userrollno==btn){
                data.splice(index,1)
            }
        })
        localStorage.setItem("book",JSON.stringify(data))
        
    }

}


 

class ui{
    static storedate(){
        var soreddatadarray=store.getdata();
        soreddatadarray.forEach(book=>{
            ui.datadisplay(book);
        })
     }
     static datadisplay(book){
        let tableshow = document.getElementById("tablecontent");
        var row = document.createElement("tr")
        row.innerHTML=`<td scope="col">#</td>
                    <td scope="col">${book.username}</td>
                    <td scope="col">${book.userbook}</td>
                    <td scope="col">${book.userrollno}</td>
                    <td scope=col class="delete">Delete</td>
                      `
        // console.log(tableshow.innerHTML)
        tableshow.appendChild(row)
        }
        static clearfields(){
            let username= document.getElementById("username").value="";
            let userbook = document.getElementById("bookname").value="";
            let userrollno = document.getElementById("rollno").value="";
        }
        static formvalue(){
            let username= document.getElementById("username").value;
            let userbook = document.getElementById("bookname").value;
            let userrollno = document.getElementById("rollno").value;
            let getvalue = [username,userbook,userrollno];
            return getvalue
        }
        static removevalue(btn){
            if(btn.target.classList.contains("delete")){
                btn.target.parentElement.remove();
            }

        }
       static messageview(message,className){
        var div =document.createElement("div");
        div.setAttribute("class",`alert alert-${className}`);
        var messageelm = document.createTextNode(message);
        div.appendChild(messageelm);
        var containerelem = document.querySelector("#mainbody");
        var formelm =document.getElementById("formbody");
        containerelem.insertBefore(div,formelm)

        // setTimeout(div.remove(),3000); 
        setInterval(()=>{
            div.remove();
        },3000);  
        
        
       }
      
    

}
ui.storedate();
document.getElementById("submitbtn").addEventListener("click",(e)=>{
    e.preventDefault();
    let formvaluesubmission= ui.formvalue();
    console.log(formvaluesubmission)
    if(formvaluesubmission[0]===""||formvaluesubmission[1]===""||formvaluesubmission[2]==="" ){
        ui.messageview("please fill out tis field","primary");
        // clearInterval(ui.messageview,1000)
    }
    else{

        console.log(formvaluesubmission)
        
        
        let obj1 = new book(...formvaluesubmission);
        ui.datadisplay(obj1)
        store.adddata(obj1)
        ui.clearfields();
        ui.messageview("thank you your form submitted","warning")
    }
        
    })
    
     document.getElementById("tablecontent").addEventListener("click",(btn)=>{
    // console.log(btn.target.innerHTML)
    ui.removevalue(btn)
    store.deldata(btn.target.previousElementSibling.innerHTML);
    ui.messageview("your row has been deleted","danger");
    

})






